package com.example.alpha;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlphaDataServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
