package com.example.alpha;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlphaDataServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlphaDataServiceApplication.class, args);
	}

}
