package com.example.beta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BetaDataServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BetaDataServiceApplication.class, args);
	}

}
